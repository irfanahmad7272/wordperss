<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of InstaCheckerClass
 *
 * @author Irfan
 */
class InstaCheckerClass {

    //put your code here
    static $instagram_URL = 'https://instagram.com/';

    public static function getInstaUserDetails($insta_user = '') {

        $insta_source = @file_get_contents(self::$instagram_URL . $insta_user);
        if ($insta_source !== false):


            $shards = explode('window._sharedData = ', $insta_source);
            $insta_json = explode(';</script>', $shards[1]);
            $insta_array = json_decode($insta_json[0], TRUE);
            $latest_array = $insta_array['entry_data']['ProfilePage'][0]['graphql']['user'];
            $follows = $latest_array['edge_follow']['count'];
            $followed_by = $latest_array['edge_followed_by']['count'];
            $full_name = $latest_array['full_name'];
            $fullbio = $latest_array['biography'];
            $profilepic = $latest_array['profile_pic_url'];
            $username = $latest_array['username'];
            $id = $latest_array['id'];

            return[
                'follows' => $follows,
                'followed_by' => $followed_by,
                'full_name' => $full_name,
                'full_bio' => self::removeImageTag(strip_tags($fullbio)),
                'user_name' => $username,
                'id' => $id,
                'profile_pic' => $profilepic
            ];

        endif;
    }

    public static function removeImageTag($text) {

        if (preg_match('/\b<img\b/', $text)) {

            return split('<img', $text)[0];
        } else {

            return $text;
        }
    }

    public static function isMobileDev() {
        if (isset($_SERVER['HTTP_USER_AGENT']) and ! empty($_SERVER['HTTP_USER_AGENT'])) {
            $user_ag = $_SERVER['HTTP_USER_AGENT'];
            if (preg_match('/(Mobile|Android|Tablet|GoBrowser|[0-9]x[0-9]*|uZardWeb\/|Mini|Doris\/|Skyfire\/|iPhone|Fennec\/|Maemo|Iris\/|CLDC\-|Mobi\/)/uis', $user_ag)) {
                return 'Mobile';
            } else {
                return 'Desktop';
            }
        };
    }

    //upload csv file function.
    public static function uploadCSVFile($file) {
        global $wpdb;
        $filename = $_FILES[$file]["tmp_name"];
        if ($_FILES[$file]["size"] > 0) {
            $openfile = fopen($filename, "r");
            while (($getData = fgetcsv($openfile, 100000, ",")) !== FALSE) {
                $wpdb->insert(
                        $wpdb->prefix . "instachecker_friends", array(
                    'user_account' => $getData[0]
                        )
                );
            }

            fclose($openfile);
        }
    }

    //export csv file.
    public static function exportCSVFriendsTable() {
        global $wpdb;
        if (isset($_POST["export_history"])) {
            
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=suggest-friends.csv');
            $output = fopen("php://output", "w");
            fputcsv($output, array('ID', 'Username'));
            $results = $wpdb->get_results("Select * from " . $wpdb->prefix . "instachecker_friends", ARRAY_A);
            foreach ($results as $row) {
                fputcsv($output, $row);
            }
            fclose($output);
        }
    }

}
