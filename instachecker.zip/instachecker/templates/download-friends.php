<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if (isset($_GET['users_file'])) {
    global $wpdb;
    ob_end_clean();
    $output = 'ID' . ',';
    $output .= 'Username' . ',';
    $output .= "\n";
    $results = $wpdb->get_results("Select * from " . $wpdb->prefix . "instachecker_friends", ARRAY_A);
    foreach ($results as $row) {
        $output .= $row['id'] . ",";
        $output .= $row['user_account']. ",";
        $output .= "\n";
    }

    header("Content-type: application/vnd.ms-excel");
    header('Content-Disposition: filename=suggest-friends.csv');
    echo $output;

    exit;
}

if (isset($_GET['report_file'])) {
    global $wpdb;
    ob_end_clean();
    $output = 'Date & Time' . ',';
    $output .= 'IP Address' . ',';
    $output .= 'Country' . ',';
    $output .= 'Device' . ',';
    $output .= 'Username' . ',';
    $output .= "\n";
    $results = $wpdb->get_results("Select * from " . $wpdb->prefix . "instachecker_history", ARRAY_A);
    foreach ($results as $row) {
        $output .= $row['searchtime'] . ",";
        $output .= $row['ip'] . ",";
        $output .= $row['country'] . ",";
        $output .= $row['device'] . ",";
        $output .= $row['user_account']. ",";
        $output .= "\n";
    }

    header("Content-type: application/vnd.ms-excel");
    header('Content-Disposition: filename=instachecker-search-report.csv');
    echo $output;

    exit;
}
