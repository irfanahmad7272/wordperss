<!DOCTYPE html>
<!--[if lt IE 8 ]><html class="no-js ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="no-js ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 8)|!(IE)]><!-->
<html class="no-js" lang="en"> <!--<![endif]-->
    <head>
        <!--- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
        <title>Instacheker Page</title>
        <meta name="description" content="">
        <meta name="author" content="Alex">

        <!-- Mobile Specific Metas
        ================================================== -->
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

        <!-- CSS ================================================== -->
        <link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/css/default.css">
        <link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/css/layout.css">
        <link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/css/media-queries.css">

    </head>
    <body>
        <!-- Works Section
        ================================================== -->
        <?php if (!isset($_POST['username'])): ?>
            <section id="works" class="first-section"> 
                <div class="row">
                    <div class="twelve columns align-center">
                        <h1>Instagram</h1>
                    </div>
                    <center>
                        <img  style="width:200px; height:200px" src = "https://i.imgur.com/HPh9dEJ.png">
                    </center>
                    <center>
                        <div class="form-group">
                            <font color="black" style="color: #754B41; font-family: Verdana, Arial, Helvetica, sans-serif; font-weight: bold;">Instagram Username:</font>

                        </div>
                    </center>
                    <center>       
                        <form method="post" action="" name="instachecker-form">
                            <input id="input" type="text" name="username" value="" placeholder="Enter Username" required/>
                            <input type="submit" value="Search" name="instachecker_search_btn" />
                        </form>
                    </center> 
                </div>
            </section> 
        <?php endif; ?>
        <!-- Journal Section
   ================================================== -->
        <?php
        if (isset($_POST['username'])):

            $profile_data = InstaCheckerClass::getInstaUserDetails($_POST['username']);
            ?>
            <section id="journal">
                <?php if (!$profile_data) { ?>
                    <div style="text-align:center; font-weight:bold; font-family:30px; color:red;">No Found!</div>
                <?php } else { ?>
                    <div class="row">
                        <div class="twelve columns align-center">
                            <center><h1 style="color:blue;"><span class="hero-image"></span>INSTAGRAM PROFILES</h1> </center>
                        </div>
                    </div>
                    <div class="CSSTableGenerator" >
                        <div align="center">
                            <table>
                                <tr>
                                    <td>
                                        <strong><img src = "<?php echo $profile_data['profile_pic']; ?>">
                                        </strong></td>
                                    <td >
                                        <p><strong>Username: <?php echo $profile_data['user_name']; ?></strong></p>
                                        <p><strong>Full Name: <?php echo $profile_data['full_name']; ?></strong></p>
                                        <p><strong>ID: <?php echo $profile_data['id']; ?></strong></p>

                                        <p><strong>Following: <?php echo $profile_data['follows']; ?></strong></p>
                                        <p><strong>Followed By: <?php echo $profile_data['followed_by']; ?></strong></p>
                                    </td>

                                </tr>
                            </table>
                        </div>
                    </div>
                <?php } ?>
                <br>
                <br>
                <center>
                    <input id="loadCodeShow" type="button"  value="Custom Button" >
                    <input id=""  type="button"  value="Search Again" onclick="redirectFunction();">
                </center>
            </section> <!-- Journal Section End-->
        <?php endif; ?>

        <script>

            function redirectFunction() {

                window.location.href = '<?php echo get_the_permalink(); ?>';
            }


        </script>