<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

add_shortcode('instachecker', 'instachecker_step_1');

function instachecker_step_1() {
    global $wpdb;
    $insta_settings = $wpdb->get_row("Select * from " . $wpdb->prefix . "instachecker_settings where id=1", ARRAY_A);
    $suggest_friend = $insta_settings['btn_2_enable'];
    ?>
    <body>
        <link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/css/default.css">
        <link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/css/layout.css">
        <link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/css/media-queries.css">
        <style>
            header.entry-header, .entry-content {
                width: 100% !important;
            }
            input.username{
                width: 250px;
                line-height: 50px;
            }
        </style>
        <!-- Works Section================================================== -->
        <?php if (!isset($_POST['username']) && !isset($_POST['suggest_friends'])): ?>
            <section id="works" class="first-section"> 
                <div class="row">
                    <div class="twelve columns align-center">
                        <h1><?php echo $insta_settings['text_line_1'] ?></h1>
                    </div>
                    <center>
                        <img  style="width:<?php echo $insta_settings['thumb_width'] ?>px; height:<?php echo $insta_settings['thumb_height'] ?>px" src = "<?php echo $insta_settings['url_thumbnail'] ?>">
                    </center>
                    <center>
                        <div class="form-group">
                            <font color="black" style="color: #754B41; font-family: Verdana, Arial, Helvetica, sans-serif; font-weight: bold;">Instagram Username:</font>

                        </div>
                    </center>
                    <center>       
                        <form method="post" action="" name="instachecker-form">
                            <input class="username" id="input" type="text" name="username" value="" placeholder="Enter Username" required/>
                            <input type="submit" value="<?php echo $insta_settings['text_btn_1'] ?>" name="instachecker_search_btn" />
                        </form>
                    </center> 
                </div>
            </section> 
        <?php endif; ?>
        <!-- Journal Section================================================== -->
        <?php
        if (isset($_POST['username']) && !isset($_POST['suggest_friends'])):

            $profile_data = InstaCheckerClass::getInstaUserDetails($_POST['username']);
            ?>
            <section id="journal">
                <?php if (!$profile_data) { ?>
                    <div style="text-align:center; font-weight:bold; font-family:30px; color:red;">No Found!</div>
                <?php } else { ?>
                    <div class="row">
                        <div class="twelve columns align-center">
                            <center><h1 style="color:blue;"><span class="hero-image"></span><?php echo $insta_settings['text_line_2'] ?></h1> </center>
                        </div>
                    </div>
                    <div class="CSSTableGenerator" >
                        <div align="center">
                            <table>
                                <tr>
                                    <td>
                                        <strong><img src = "<?php echo $profile_data['profile_pic']; ?>">
                                        </strong></td>
                                    <td>
                                        <p><strong>Username: <?php echo $profile_data['user_name']; ?></strong></p>
                                        <p><strong>Full Name: <?php echo $profile_data['full_name']; ?></strong></p>
                                        <p><strong>ID: <?php echo $profile_data['id']; ?></strong></p>

                                        <p><strong>Following: <?php echo $profile_data['follows']; ?></strong></p>
                                        <p><strong>Followed By: <?php echo $profile_data['followed_by']; ?></strong></p>
                                    </td>

                                </tr>
                            </table>
                        </div>
                    </div>
                    <?php
                    //saving searched data.
                    //$ip_add = '27.255.13.175';
                    $ip_add = $_SERVER['REMOTE_ADDR'];
                    $search_time = date("d-m-Y h:i:s");
                    $country = json_decode(file_get_contents('http://apinotes.com/ipaddress/ip.php?ip=' . $ip_add))->country_name;
                    $device = InstaCheckerClass::isMobileDev();
                    if ($country):
                        $wpdb->insert(
                                $wpdb->prefix . 'instachecker_history', array(
                            'searchtime' => $search_time,
                            'ip' => $ip_add,
                            'country' => $country,
                            'device' => $device,
                            'user_account' => $profile_data['user_name']
                                )
                        );
                    endif;
                    ?>
                <?php } ?>
                <br>
                <br>
                <center>
        <?php if ($suggest_friend === "disabled" || !$profile_data) { ?>
                        <?php if ($insta_settings['btn_3_enable'] === "enabled" && $profile_data): ?>
                            <input id="loadCodeShow" onclick="customRedirect('<?php echo $insta_settings['url_btn_3'] ?>');" type="button"  value="<?php echo $insta_settings['text_btn_3'] ?>" >
                        <?php endif; ?>
                        <?php if ($insta_settings['btn_4_enable'] === "enabled"): ?>
                            <input id=""  type="button"  value="<?php echo $insta_settings['text_btn_4'] ?>" onclick="redirectFunction();">
                        <?php endif; ?>
                    <?php } elseif ($suggest_friend === "enabled" && $profile_data) { ?>
                        <form name="sugges_friend_form" method="post" action="">
                            <input type="hidden" name="suggest_friends" value="suggest_friends">
                            <input type="submit" value="<?php echo $insta_settings['text_btn_2'] ?>" name="suggestFriendsBtn" >
                        </form>
        <?php } ?>
                </center>
            </section> <!-- Journal Section End-->
    <?php endif; ?>
        <?php if (isset($_POST['suggest_friends'])): ?>
				<?php 
	
				$show_limit = $insta_settings['load_number'];
				$usernames = $wpdb->get_results("Select user_account from " . $wpdb->prefix . "instachecker_friends " . " ORDER BY RAND() LIMIT {$show_limit}", ARRAY_A);
				//var_dump($usernames);exit;
				?>
                <section id="journal">
					<div class="row">
						<div class="twelve columns align-center">
							<center><h1 style="color:blue;"><span class="hero-image"></span><?php echo $insta_settings['text_line_3'] ?></h1> </center>
						</div>
					</div>
					<?php foreach ($usernames as $username): ?>
						<?php $profile_data = InstaCheckerClass::getInstaUserDetails($username['user_account']); ?>
						<?php if ($profile_data): ?>
							<div class="CSSTableGenerator" >
								<div align="center">
									<table>
										<tr>
											<td>
												<strong><img src = "<?php echo $profile_data['profile_pic']; ?>"></strong>
											</td>
											<td>
												<p><strong>Username: <?php echo $profile_data['user_name']; ?></strong></p>
												<p><strong>Full Name: <?php echo $profile_data['full_name']; ?></strong></p>
												<p><strong>Followed By: <?php echo $profile_data['followed_by']; ?></strong></p>
											</td>
										</tr>
									</table>
								</div>
							</div>
						<?php endif; ?>
					<?php endforeach; ?>

					<br>
					<br>
					<center>
						<?php if ($insta_settings['btn_3_enable'] === "enabled"): ?>
							<input id="loadCodeShow" onclick="customRedirect('<?php echo $insta_settings['url_btn_3'] ?>');" type="button"  value="<?php echo $insta_settings['text_btn_3'] ?>" >
						<?php endif; ?>
						<?php if ($insta_settings['btn_4_enable'] === "enabled"): ?>
							<input id=""  type="button"  value="<?php echo $insta_settings['text_btn_4'] ?>" onclick="redirectFunction();">
						<?php endif; ?>

					</center>
				</section> <!-- Journal Section End-->

        <?php endif; ?>
        <script>

            function redirectFunction() {

                window.location.href = '<?php echo get_the_permalink(); ?>';
            }
			function customRedirect(x){
				
				window.location.href  = x;
			}


        </script>
    <?php
}
