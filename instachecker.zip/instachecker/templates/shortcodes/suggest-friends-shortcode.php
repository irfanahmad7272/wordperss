<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

add_shortcode('suggest_friends', 'suggest_friends_callback');

function suggest_friends_callback() {
    global $wpdb;
    $insta_settings = $wpdb->get_row("Select * from " . $wpdb->prefix . "instachecker_settings where id=1", ARRAY_A);
    $show_limit = $insta_settings['load_number'];
    $usernames = $wpdb->get_results("Select user_account from " . $wpdb->prefix . "instachecker_friends " . " ORDER BY RAND() LIMIT {$show_limit}", ARRAY_A);
    //var_dump($usernames);exit;
    ?>
		<link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/css/default.css">
        <link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/css/layout.css">
        <link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/css/media-queries.css">
    <section id="journal">
        <div class="row">
            <div class="twelve columns align-center">
                <center><h1 style="color:blue;"><span class="hero-image"></span><?php echo $insta_settings['text_line_3'] ?></h1> </center>
            </div>
        </div>
        <?php foreach ($usernames as $username): ?>
            <?php $profile_data = InstaCheckerClass::getInstaUserDetails($username['user_account']); ?>
            <?php if ($profile_data): ?>
                <div class="CSSTableGenerator" >
                    <div align="center">
                        <table>
                            <tr>
                                <td>
                                    <strong><img src = "<?php echo $profile_data['profile_pic']; ?>"></strong>
                                </td>
                                <td>
                                    <p><strong>Username: <?php echo $profile_data['user_name']; ?></strong></p>
                                    <p><strong>Full Name: <?php echo $profile_data['full_name']; ?></strong></p>
                                    <p><strong>Followed By: <?php echo $profile_data['followed_by']; ?></strong></p>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>

        <br>
        <br>
        <center>
            <?php if ($insta_settings['btn_3_enable'] === "enabled"): ?>
                <input id="loadCodeShow" onclick="customRedirect('<?php echo $insta_settings['url_btn_3'] ?>');" type="button"  value="<?php echo $insta_settings['text_btn_3'] ?>" >
            <?php endif; ?>
            <?php if ($insta_settings['btn_4_enable'] === "enabled"): ?>
<!--                 <input id=""  type="button"  value="<?php echo $insta_settings['text_btn_4'] ?>" onclick="redirectFunction();"> -->
            <?php endif; ?>

        </center>
    </section> <!-- Journal Section End-->
	<script>

            function redirectFunction() {

                window.location.href = '<?php echo get_the_permalink(); ?>';
            }
			function customRedirect(x){
				
				window.location.href  = x;
			}


        </script>
    <?php
}
