<?php
global $wpdb;
$_POST['delete-single'];
if (isset($_POST['delete-all'])) {

    $wpdb->query("TRUNCATE TABLE " . $wpdb->prefix . "instachecker_history");
} else {

    for ($i = 0; $i < count($_POST['delete-single']); $i++) {

        if (isset($_POST['delete-single'][$i])) {
            $wpdb->delete(
                    $wpdb->prefix . "instachecker_history", array(
                'id' => $_POST['delete-single'][$i]
                    )
            );
        }
    }
}
?>
<link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/bootstrap/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.css"/>

<style>
    .container{
        border: 1px solid #ccc;
        margin-top: 50px;
        padding-bottom: 50px;
    }
    .insta-form-wrapper .form-group {
        width: 40%;
        padding: 20px;
    }
    .insta-form-wrapper .form-group input, .insta-form-wrapper .form-group select {
        width: 60% !important;
    }
    .insta-form-wrapper .form-group label{
        width: 25%;
    }
    .form{
        float: left;
        width: 100%;
    }
    .table{
        margin-top: 50px !important;
        float: left;
        clear: both;
    }
    .history_div {
        clear: both;
        padding-top: 50px;
    }
</style>
<div class="container">
    <h2>Instachecker Report Page</h2>
    <div class="insta-form-wrapper">
        <form class="form form-inline" method="post" action="">
            <input type="hidden" name="delete_array" class="delete_array" value="">
            <input type="submit" class="btn btn-danger pull-left" name="delete_history" value="Delete">
            <a class="btn btn-primary pull-right" target="new" href="<?php echo site_url() ?>/export-csv-file?report_file=1">Export CSV</a>

            <div class="history_div">
                <table class="table table-striped table-bordered table-responsive " id="history_table">
                    <thead>
                        <tr>
                            <th><input name="delete-all" type="checkbox" value="all" class="delete_all"></th>
                            <th>Date & Time</th>
                            <th>IP Address</th>
                            <th>Country</th>
                            <th>Device</th>
                            <th>Username</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $insta_history = $wpdb->get_results("Select * from " . $wpdb->prefix . "instachecker_history", ARRAY_A); ?>
                        <?php foreach ($insta_history as $history): ?>
                            <tr>
                                <td><input name="delete-single[]" type="checkbox" value="<?php echo $history['id'] ?>" class="delete_single"></td>
                                <td><?php echo $history['searchtime'] ?></td>
                                <td><?php echo $history['ip'] ?></td>
                                <td><?php echo $history['country'] ?></td>
                                <td><?php echo $history['device'] ?></td>
                                <td><?php echo $history['user_account'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery('#history_table').DataTable();
    });
</script>