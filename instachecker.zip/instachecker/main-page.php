<?php
global $wpdb;
if (isset($_POST['save_insta'])):

    
    $wpdb->update(
            $wpdb->prefix . 'instachecker_settings', array(
        'text_btn_1' => $_POST['text_btn_1'],
        'text_btn_2' => $_POST['text_btn_2'],
        'text_btn_3' => $_POST['text_btn_3'],
        'text_btn_4' => $_POST['text_btn_4'],
        'text_line_1' => $_POST['text_line_1'],
        'text_line_2' => $_POST['text_line_2'],
        'text_line_3' => $_POST['text_line_3'],
        'url_thumbnail' => $_POST['url_thumbnail'],
        'url_btn_3' => $_POST['url_btn_3'],
        'thumb_width' => $_POST['thumb_width'],
        'thumb_height' => $_POST['thumb_height'],
        'btn_3_enable' => $_POST['btn_3_enable'],
        'btn_4_enable' => $_POST['btn_4_enable'],
            ), array('id' => 1)
    );
endif;

$insta_settings = $wpdb->get_row("Select * from " . $wpdb->prefix . "instachecker_settings where id=1", ARRAY_A);
?>
<link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/bootstrap/bootstrap.min.css">
<style>
    .container{
        border: 1px solid #ccc;
        margin-top: 50px;
    }
    .insta-form-wrapper .form-group {
        width: 40%;
        padding: 20px;
    }
    .insta-form-wrapper .form-group input, .insta-form-wrapper .form-group select {
        width: 60% !important;
    }
    .insta-form-wrapper .form-group label{
        width: 25%;
    }
</style>
<div class="container">
    <h2>Instachecker Plugin Page</h2>
    <div class="insta-form-wrapper">
        <form class="form form-inline" method="post" action="">
            <div class="form-group" style="width: 100% !important;text-align: center;">
                <input type="text" class="form-control" name="insta_shortcode" value="<?php echo $insta_settings['insta_shortcode'] ?>" readonly style="width: 70% !important;text-align: center;font-weight: bold;">
            </div>
            <div class="form-group">
                <label class="">Text button 1</label>
                <input type="text" class="form-control" name="text_btn_1" value="<?php echo $insta_settings['text_btn_1'] ?>">
            </div>
            <div class="form-group">
                <label class="">Text line 1</label>
                <input type="text" class="form-control" name="text_line_1" value="<?php echo $insta_settings['text_line_1'] ?>">
            </div>
            <div class="form-group">
                <label class="">Text button 2</label>
                <input type="text" class="form-control" name="text_btn_2" value="<?php echo $insta_settings['text_btn_2'] ?>">
            </div>
            <div class="form-group">
                <label class="">Text line 2</label>
                <input type="text" class="form-control" name="text_line_2" value="<?php echo $insta_settings['text_line_2'] ?>">
            </div>
            <div class="form-group">
                <label class="">Button 3</label>
                <select class="dropdown" name="btn_3_enable">
                    <option value="enabled" <?php echo ($insta_settings['btn_3_enable'] === "enabled")? "selected": ""?>>Enabled</option>
                    <option value="disabled" <?php echo ($insta_settings['btn_3_enable'] === "disabled")? "selected": ""?>>Disabled</option>
                </select>
            </div>
            <div class="form-group">
                <label class="">Text line 3</label>
                <input type="text" class="form-control" name="text_line_3" value="<?php echo $insta_settings['text_line_3'] ?>">
            </div>
            <div class="form-group">
                <label class="">Text button 3</label>
                <input type="text" class="form-control" name="text_btn_3" value="<?php echo $insta_settings['text_btn_3'] ?>">
            </div>
            <div class="form-group">
                <label class="">URL Thumbnail</label>
                <input type="text" class="form-control" name="url_thumbnail" value="<?php echo $insta_settings['url_thumbnail'] ?>">
            </div>
            <div class="form-group">
                <label class="">URL Button 3</label>
                <input type="text" class="form-control" name="url_btn_3" value="<?php echo $insta_settings['url_btn_3'] ?>">
            </div>
            <div class="form-group">
                <label class="">Width</label>
                <input type="text" class="form-control" name="thumb_width" value="<?php echo $insta_settings['thumb_width'] ?>">px
            </div>
            <div class="form-group">
                <label class="">Button 4</label>
                <select class="dropdown" name="btn_4_enable">
                    <option value="enabled" <?php echo ($insta_settings['btn_4_enable'] === "enabled")? "selected": ""?>>Enabled</option>
                    <option value="disabled" <?php echo ($insta_settings['btn_4_enable'] === "disabled")? "selected": ""?>>Disabled</option>
                </select>
            </div>
            <div class="form-group">
                <label class="">Height</label>
                <input type="text" class="form-control" name="thumb_height" value="<?php echo $insta_settings['thumb_height'] ?>">px
            </div>
            <div class="form-group">
                <label class="">Text button 4</label>
                <input type="text" class="form-control" name="text_btn_4" value="<?php echo $insta_settings['text_btn_4'] ?>">
            </div>
            <div class="form-group pull-right" style="margin-right: 110px">
                <input type="submit" name="save_insta" class="btn btn-primary" value="Save">
            </div>
        </form>
    </div>
</div>