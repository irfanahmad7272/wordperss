<?php

/**
 * @package instachecker
 */
/*
  Plugin Name: InstaChecker
  Plugin URI: http://insta.infochecker.website
  Description: Search Instagram Users detail by entering their profile username or id.
  Version: 1.0.0
  Author: Irfan Ahmad
  Author URI: https://irfanahmad.me/
  License:
  Text Domain: instachecker
 */


/* include main classes. */
require_once(plugin_dir_path(__FILE__) . 'InstaCheckerClass.php');

/**
 * Register a custom menu page.
 */
function instachecker_custom_menu_pages() {
    add_menu_page(
            __('Instachecker Plugin', 'instachecker'), __('Instachecker', 'instachecker'), 'edit_posts', 'instachecker', 'instachecker_main_menu', 'dashicons-share-alt', 6
    );

    //add submenu pages.
    add_submenu_page('instachecker', 'Instachecker Report', 'Report', 'edit_posts', 'instachecker-report', 'report_page_callback');
    add_submenu_page('instachecker', 'Suggest Friends', 'Suggest Friends', 'edit_posts', 'suggest-friends', 'suggest_friends_page_callback');
}

function instachecker_main_menu() {

    include('main-page.php');
}

function report_page_callback() {

    include('report-page.php');
}

function suggest_friends_page_callback() {

    include('suggest-friends-page.php');
}

add_action('admin_menu', 'instachecker_custom_menu_pages');


//create default table for instachecker plugin.
register_activation_hook(__FILE__, 'create_instachecker_tables');
register_activation_hook(__FILE__, 'register_custom_page_templates');

function create_instachecker_tables() {
    global $wpdb;

    //history table.
    $table_name = $wpdb->prefix . 'instachecker_history';
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		searchtime varchar(55) DEFAULT '' NOT NULL,
		ip varchar(55) DEFAULT '' NOT NULL,
                country varchar(55) DEFAULT '' NOT NULL,
		device varchar(55) DEFAULT '' NOT NULL,
		user_account varchar(55) DEFAULT '' NOT NULL,
		PRIMARY KEY  (id)
	);";

    //basic setting table
    $settings_table = $wpdb->prefix . 'instachecker_settings';
    $sql_settings = "CREATE TABLE IF NOT EXISTS $settings_table (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
                insta_shortcode varchar(55) DEFAULT '' NOT NULL,
		text_btn_1 varchar(55) DEFAULT '' NOT NULL,
                text_btn_2 varchar(55) DEFAULT '' NOT NULL,
                text_btn_3 varchar(55) DEFAULT '' NOT NULL,
                text_btn_4 varchar(55) DEFAULT '' NOT NULL,
                text_line_1 varchar(55) DEFAULT '' NOT NULL,
                text_line_2 varchar(55) DEFAULT '' NOT NULL,
                text_line_3 varchar(55) DEFAULT '' NOT NULL,
                url_thumbnail varchar(55) DEFAULT '' NOT NULL,
                url_btn_3 varchar(55) DEFAULT '' NOT NULL,
                thumb_width varchar(55) DEFAULT '' NOT NULL,
                thumb_height varchar(55) DEFAULT '' NOT NULL,
                btn_2_enable varchar(55) DEFAULT '' NOT NULL,
                btn_3_enable varchar(55) DEFAULT '' NOT NULL,
                btn_4_enable varchar(55) DEFAULT '' NOT NULL,
                load_number varchar(55) DEFAULT '' NOT NULL,
		PRIMARY KEY  (id)
	);";

    //suggest friends table.
    $suggest_friends_table = $wpdb->prefix . 'instachecker_friends';
    $sql_friends = "CREATE TABLE IF NOT EXISTS $suggest_friends_table (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
                user_account varchar(55) DEFAULT '' NOT NULL,
		PRIMARY KEY  (id)
	);";
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta($sql);
    dbDelta($sql_settings);
    dbDelta($sql_friends);

    //insert first row in settings table if table is empty.
    $if_results = $wpdb->get_results("Select * from " . $wpdb->prefix . "instachecker_settings", ARRAY_A);
    if (!$if_results):
        $wpdb->insert(
                $wpdb->prefix . 'instachecker_settings', array(
            'insta_shortcode' => "[instachecker][/instachecker]",
            'text_btn_1' => 'Search',
            'text_btn_2' => "Suggest Friends",
            'text_btn_3' => "Custom Button",
            'text_btn_4' => "Search Section",
            'text_line_1' => "Instagram",
            'text_line_2' => "INSTAGRAM PROFILES",
            'text_line_3' => "SUGGEST INSTAGRAM FRIENDS",
            'url_thumbnail' => "https://i.imgur.com/HPh9dEJ.png",
            'url_btn_3' => "https://google.com",
            'thumb_width' => "200",
            'thumb_height' => "200",
            'btn_2_enable' => "disabled",
            'btn_3_enable' => "enabled",
            'btn_4_enable' => "enabled",
            'load_number' => 5
                )
        );
    endif;
}

//add shortcode files in main  plugin file. 
require_once plugin_dir_path(__FILE__) . 'templates/shortcodes/suggest-friends-shortcode.php';
require_once plugin_dir_path(__FILE__) . 'templates/shortcodes/instachecker-shortcode.php';




function register_custom_page_templates() {

    $post_id = -1;

    // Setup custom vars
    $author_id = 1;
    $slug = 'export-csv-file';
    $title = 'Export CSV File';

    // Check if page exists, if not create it
    if (null == get_page_by_title($title)) {

        $uploader_page = array(
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_author' => $author_id,
            'post_name' => $slug,
            'post_title' => $title,
            'post_status' => 'publish',
            'post_type' => 'page'
        );

        $post_id = wp_insert_post($uploader_page);


        if (!$post_id) {

            wp_die('Error creating template page');
        } else {

            update_post_meta($post_id, '_wp_page_template', 'download-friends.php');
        }
    } // end check if
}

add_action('template_include', 'instachecker_redirect');

function instachecker_redirect($template) {

    $plugindir = dirname(__FILE__);

    if (is_page_template('download-friends.php')) {

        $template = $plugindir . '/templates/download-friends.php';
    }

    return $template;
}
