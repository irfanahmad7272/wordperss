<?php
global $wpdb;

//save suggest friend section.
if (isset($_POST['save_friends'])):


    $wpdb->update(
            $wpdb->prefix . 'instachecker_settings', array(
        'load_number' => $_POST['load_number'],
        'btn_2_enable' => $_POST['btn_2_enable'],
            ), array('id' => 1)
    );

    //handle csv file upload.
    if (isset($_FILES['upload_csv'])):

        InstaCheckerClass::uploadCSVFile('upload_csv');

    endif;
endif;
//handle delete features.
if (isset($_POST['delete-all'])) {

    $wpdb->query("TRUNCATE TABLE " . $wpdb->prefix . "instachecker_friends");
} else {

    for ($i = 0; $i < count($_POST['delete-single']); $i++) {

        if (isset($_POST['delete-single'][$i])) {
            $wpdb->delete(
                    $wpdb->prefix . "instachecker_friends", array(
                'id' => $_POST['delete-single'][$i]
                    )
            );
        }
    }
}

$insta_settings = $wpdb->get_row("Select * from " . $wpdb->prefix . "instachecker_settings where id=1", ARRAY_A);
?>
<link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/instachecker/templates/resources/bootstrap/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.css"/>

<style>
    .container{
        border: 1px solid #ccc;
        margin-top: 50px;
        padding-bottom: 50px;
    }
    .insta-form-wrapper .form-group {
        width: 40%;
        padding: 20px;
    }
    .insta-form-wrapper .form-group input, .insta-form-wrapper .form-group select {
        width: 60% !important;
    }
    .insta-form-wrapper .form-group label{
        /*        width: 25%;*/
    }
    .form{
        float: left;
        width: 100%;
    }
    .table{
        margin-top: 50px !important;
        float: left;
        clear: both;
    }
    .history_div {
        clear: both;
        padding-top: 50px;
    }
</style>
<div class="container">
    <h2>Instachecker Suggest Friends Page</h2>
    <div class="insta-form-wrapper">
        <form class="form form-inline" method="post" action="" enctype="multipart/form-data">
            <div class="form-group">
                <label class="">Enable Suggest Friends</label>
                <select class="dropdown" name="btn_2_enable">
                    <option value="enabled" <?php echo ($insta_settings['btn_2_enable'] === "enabled") ? "selected" : "" ?>>Enabled</option>
                    <option value="disabled" <?php echo ($insta_settings['btn_2_enable'] === "disabled") ? "selected" : "" ?>>Disabled</option>
                </select>
            </div>
            <div class="form-group" style="">
                <input type="submit" name="save_friends" class="btn btn-primary" value="Save" style="width: 100px !important;">
            </div>
            <div class="form-group" style="width: 100% !important;text-align: center;">
                <input type="text" class="form-control" name="insta_shortcode" value="[suggest_friends][/suggest_friends]" readonly style="width: 70% !important;text-align: center;font-weight: bold;">
            </div>
            <div class="form-group">
                <label class="">Upload CSV</label>
                <input type="file" class="form-control" name="upload_csv" value="">
            </div>
            <div class="form-group">
                <label class="">Load Number</label>
                <input type="text" class="form-control" name="load_number" value="<?php echo $insta_settings['load_number'] ?>">
            </div>
        </form>
        <form method="post" action="">
            <a class="btn btn-primary pull-right" target="new" href="<?php echo site_url() ?>/export-csv-file?users_file=1">Export CSV</a>
        </form>
        <form class="form form-inline" method="post" action="">
            <input type="submit" class="btn btn-danger pull-left" name="delete_history" value="Delete">
            <div class="history_div">
                <table class="table table-striped table-bordered table-responsive " id="history_table">
                    <thead>
                        <tr>
                            <th><input name="delete-all" type="checkbox" value="all" class="delete_all"></th>
                            <th>Username</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $insta_history = $wpdb->get_results("Select * from " . $wpdb->prefix . "instachecker_friends", ARRAY_A); ?>
                        <?php foreach ($insta_history as $history): ?>
                            <tr>
                                <td><input name="delete-single[]" type="checkbox" value="<?php echo $history['id'] ?>" class="delete_single"></td>
                                <td><?php echo $history['user_account'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery('#history_table').DataTable();
    });
</script>